# Interactive_Planner
An application to save notes and events, track your life and thoughts
this is an edit
